# 如何在自己的App中接入猫影视TV的自定义jar

```
思维没有边界 一切皆有可能
```
:rocket:[**TG交流群**](https://t.me/catvodtv_offical)

![logo](app/src/main/res/drawable-xhdpi/app_icon.png)



使用 DexClassLoader 和 反射 获取jar包内的爬虫类，并调用相关数据接口，App中解析爬虫接口返回的数据展示界面及其他相关处理即可，只是个例子，道理都一样。